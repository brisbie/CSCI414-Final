## Failure and recovery

| Scenario | Detected after (s) | Healing action | Service restored after (s) | Total outage seen by client (s) | Monitor-observed outage (s) | Verify request |
|---|---|---|---|---|---|---|
| api-crash | 8.4 | start_api | 1.1 | 9.5 | 9.0 | HTTP 200 |
| db-crash | 8.4 | start_mongo | 1.2 | 9.6 | 9.0 | HTTP 200 |
| link-down | 8.3 | link_up(eth1) | 0.8 | 9.1 | 7.5 | HTTP 200 |
