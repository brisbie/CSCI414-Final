## Application latency (client-side, ms; identical seeded workload per condition)

| Condition | OK / total | Error % | Mean | p50 | p95 | p99 | Max | Throughput (req/s) |
|---|---|---|---|---|---|---|---|---|
| baseline | 300/300 | 0.00 | 2.0 | 2.0 | 3.0 | 3.5 | 4.2 | 493.93 |
| delay | 300/300 | 0.00 | 96.8 | 88.6 | 140.1 | 150.6 | 153.8 | 10.33 |
| loss | 300/300 | 0.00 | 12.8 | 2.2 | 22.1 | 212.1 | 261.7 | 77.81 |
| rate | 300/300 | 0.00 | 5.2 | 3.4 | 14.0 | 14.5 | 14.8 | 189.68 |
| congested | 245/300 | 18.33 | 1676.0 | 3.8 | 9650.9 | 12092.0 | 14706.9 | 0.41 |
| dbdelay | 300/300 | 0.00 | 18.8 | 12.9 | 34.2 | 34.4 | 34.5 | 53.10 |

## Latency breakdown (medians, ms)

| Condition | MongoDB | API non-DB | Network + TLS + client | Total p50 |
|---|---|---|---|---|
| baseline | 0.66 | 0.61 | 0.81 | 2.05 |
| delay | 31.00 | 0.27 | 54.06 | 88.62 |
| loss | 0.65 | 0.64 | 0.89 | 2.16 |
| rate | 1.55 | 0.45 | 1.47 | 3.44 |
| congested | 1.68 | 0.50 | 1.57 | 3.77 |
| dbdelay | 10.91 | 0.86 | 1.08 | 12.89 |

## Network-level measurements

| Condition | ICMP RTT avg (ms) | RTT mdev (ms) | Ping loss % | TCP connect (ms) | TLS handshake (ms) | iperf3 (Mbit/s) | iperf3 retrans | pcap retrans | pcap dup ACKs |
|---|---|---|---|---|---|---|---|---|---|
| baseline | 0.06 | 0.01 | 0.0 | 0.28 | 2.65 | 50806.26 | 90 | 0 | 0 |
| delay | 52.06 | 6.81 | 0.0 | 46.94 | 50.77 | 352.82 | 150 | 48 | 357 |
| loss | 0.07 | 0.02 | 6.0 | 0.29 | 2.70 | 431.89 | 12205 | 21 | 13 |
| rate | 0.22 | 0.01 | 0.0 | 0.40 | 6.26 | 9.48 | 0 | 43 | 43 |
| congested | 0.24 | 0.18 | 0.0 | 0.38 | 6.27 | – | – | 52 | 33 |
| dbdelay | 0.05 | 0.01 | 0.0 | 0.28 | 2.62 | 49863.95 | 0 | 0 | 0 |

## p50 latency per operation (ms)

| Condition | list_products | get_product | create_order | get_order | pay_order |
|---|---|---|---|---|---|
| baseline | 2.3 | 1.4 | 2.5 | 1.4 | 2.2 |
| delay | 81.9 | 79.7 | 133.2 | 81.7 | 109.0 |
| loss | 2.4 | 1.4 | 2.6 | 1.4 | 2.2 |
| rate | 13.9 | 2.4 | 3.8 | 2.4 | 3.5 |
| congested | 14.1 | 2.6 | 3.8 | 2.5 | 3.6 |
| dbdelay | 12.9 | 12.0 | 33.9 | 12.0 | 23.2 |
